﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeadFile
{
    public class MasterFile
    {

        public LocationField checker;
        public LocationField insuranceRules;
        public LocationField customerDetails;
        public LocationField welcome;
        public LocationField invalidMsg;
        public LocationField showLabelMsg;

    }
    public class LocationField
    {
        public string location;
    }
 
}
