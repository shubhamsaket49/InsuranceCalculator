﻿using Newtonsoft.Json;
using System;
using System.IO;

namespace HeadFile
{
    public class MasterPathFile
    {
        public static MasterFile GetMasterFile()
        {
            string path = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\HeadFile\HeadFile\File\MasterFileLocation.json";
            return JsonConvert.DeserializeObject<MasterFile>(File.ReadAllText(path));
           
        }
    }
}
