﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCalc.Models
{
    public class ShowLabel
    {
        public QuestionField choice;
        public QuestionField sumValue;
        public QuestionField duration;
        public QuestionField age;
        public QuestionField smokingChoice;
    }
}

