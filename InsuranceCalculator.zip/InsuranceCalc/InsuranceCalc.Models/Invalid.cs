﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCalc.Models
{
    public class Invalid
    {
        public QuestionField invalidEndowment;
        public QuestionField invalidTerm;
        public QuestionField invalidSmokingStatus;
        public QuestionField invalidAge;
        public QuestionField invalidChoices;
        public QuestionField invalidTenure;
    }
}
