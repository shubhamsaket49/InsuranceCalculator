﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCalc.Models
{
   
        public class KYCDetails:Checkers
        {
            public QuestionField firstName;
            public QuestionField lastName;
            public QuestionField dob;
            public OptionField gender;
            public QuestionField invalidGenderSelection;
            public QuestionField adhaar;
            public QuestionField pan;
            public QuestionField invalidAdhaar;
        }
}
