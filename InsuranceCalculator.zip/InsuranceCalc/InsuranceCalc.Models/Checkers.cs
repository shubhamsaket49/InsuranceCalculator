﻿using System;
using System.Collections.Generic;


namespace InsuranceCalc.Models
{
    public class Checkers
    {
        public QuestionField termSum;
        public QuestionField endowmentSum;
        public QuestionField age;
        public OptionField smoker;
        public QuestionField tenure;
        public QuestionField finalPremium;
        public QuestionField term;
        public QuestionField endowment;
        public QuestionField choice;
    }

    public class QuestionField
    {
        public string question;
    }
    public class OptionField : QuestionField
    {
        public Dictionary<string, string> options;
    }

}

