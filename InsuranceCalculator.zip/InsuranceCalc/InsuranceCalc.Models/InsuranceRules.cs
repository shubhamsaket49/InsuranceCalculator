﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCalc.Models
{
    public class InsuranceRules
    {
        public RulesField term;
        public RulesField endowment;
    }
    public class RulesField
    {
        public SumAssured sumAssured;
        public List<AgeItem> age;
        public UserSmokerField smokingStatus;
        public double tax;
    }

    public class AgeItem
    {
        public int minRange;
        public int maxRange;
        public double percent;
    }

    public class SumAssured
    {
        public int minAmount;
        public int maxAmount;
        public int steps;
    }

    public class UserSmokerField
    {
        public double smoker;
        public double notSmoker;
    }
}
