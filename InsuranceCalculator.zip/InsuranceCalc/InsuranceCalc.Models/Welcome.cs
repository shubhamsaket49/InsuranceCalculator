﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCalc.Models
{
    public class Welcome:QuestionField
    {
        public QuestionField greeting;
        public OptionField insuranceChoice;
    }
}
