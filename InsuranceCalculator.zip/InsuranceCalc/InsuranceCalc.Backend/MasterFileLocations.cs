﻿using HeadFile;
using InsuranceCalc.Models;
using Newtonsoft.Json;
using System;
using System.IO;
namespace InsuranceCalc.Backend
{
    public class MasterFileLocations
    {
        public static Checkers CheckQues;
        public static InsuranceRules Rules;
        public static KYCDetails KycQues;
        public static MasterFile MasterFileLocation;
        public static Welcome WelcomeMsg;
        public static Invalid InvalidMsg;
        public static ShowLabel ShowLabel;

        public static void LoadLocations()
        {
            MasterFileLocation = MasterPathFile.GetMasterFile();

            string getCommonCheckerFileLocation = MasterFileLocation.checker.location;
            CheckQues = JsonConvert.DeserializeObject<Checkers>(File.ReadAllText(getCommonCheckerFileLocation));

            string insuranceRulesFilePath = MasterFileLocation.insuranceRules.location;
            Rules = JsonConvert.DeserializeObject<InsuranceRules>(File.ReadAllText(insuranceRulesFilePath));

            string customerDetailsFilePath = MasterFileLocation.customerDetails.location;
            KycQues = JsonConvert.DeserializeObject<KYCDetails>(File.ReadAllText(customerDetailsFilePath));

            string welcomeMsgFilePath = MasterFileLocation.welcome.location;
            WelcomeMsg = JsonConvert.DeserializeObject<Welcome>(File.ReadAllText(welcomeMsgFilePath));

            string invalidMsgFilePath = MasterFileLocation.invalidMsg.location;
            InvalidMsg = JsonConvert.DeserializeObject<Invalid>(File.ReadAllText(invalidMsgFilePath));

            string showLabelFilePath = MasterFileLocation.showLabelMsg.location;
            ShowLabel = JsonConvert.DeserializeObject<ShowLabel>(File.ReadAllText(showLabelFilePath));
        }
    }
}
