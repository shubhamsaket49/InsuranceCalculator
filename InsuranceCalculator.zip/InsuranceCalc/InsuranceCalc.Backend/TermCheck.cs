﻿using System;
namespace InsuranceCalc.Backend
{
    /// <summary>
    /// This class check all term insurance constraints and has inherited with class common check
    /// </summary>
    public class TermCheck : CommonCheck
    {
        private static readonly log4net.ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private int _sumAssured;
        private double _smokerPercent;
        protected double Tax;

        /// <summary>
        /// This method should use to validate the term amount entered by user.
        /// </summary>
        /// <exception cref="Exception">It will throw an error when user entered term amount which is out of the range.
        /// </exception>

      
        /// <summary>
        /// This method is used to set the term amount.
        /// </summary>
        /// <param name="SumAssured">set the term amount.
        /// </param>

        public void TermSumAssured(int SumAssured)
        {
            _sumAssured = SumAssured;
        }

        /// <summary>
        /// This method will return the term amount.
        /// </summary>
        /// <returns>
        /// Term amount.
        /// </returns>
        public int GetTermSum()
        {
            return _sumAssured;
        }

        /// <summary>
        /// This method should return the respective percent according to the age.
        /// </summary>
        /// <param name="Age">This parameter helps to pass the age of the user in this method.</param>
        /// <returns>
        /// Percent based on the age of the user.
        /// </returns>
        /// <exception cref="Exception">
        /// Thrown if the age entered by user is not in the given range.
        /// </exception>

        public double SetTermPercent()
        {
            int age=GetAge();
            for (int i = 0; i < MasterFileLocations.Rules.term.age.Count; i++)
            {
                int MinAge = MasterFileLocations.Rules.term.age[i].minRange;
                int MaxAge = MasterFileLocations.Rules.term.age[i].maxRange;
                double Percent = MasterFileLocations.Rules.term.age[i].percent;
                if (age >= MinAge && age <= MaxAge)
                    return Percent;
            }
            throw new Exception(MasterFileLocations.InvalidMsg.invalidAge.question);
        }

        /// <summary>
        /// This method should return the respective percent according to the smoking status of the user.
        /// </summary>
        /// <param name="isSmoker">This parameter helps to pass the age of the user in this method.</param>
        /// <returns>
        /// Percent based on smoking status.
        /// </returns>

        public double SetTermSmokerPercent()
        {
            IsSmoker isSmoker = GetSmoker();
            _smokerPercent = MasterFileLocations.Rules.term.smokingStatus.smoker;
            double _nonSmokerPercent = MasterFileLocations.Rules.term.smokingStatus.notSmoker;
            if (IsSmoker.Smoker==isSmoker)
            {
                return _smokerPercent;
            }
           return _nonSmokerPercent;
        }

        /// <summary>
        /// This method should return total percent according to the age and smoking status of user.
        /// </summary>
        /// <returns>
        /// Total percent.
        /// </returns>

        public double SetTotalTermPercent()
        {
            double termSmokerPercent = SetTermSmokerPercent();
            double percent = SetTermPercent();
            return termSmokerPercent + percent;
        }

        /// <summary>
        /// This method returns the percent of tax added while opting Term insurance policy.
        /// </summary>
        /// <returns>
        /// Tax percent.
        /// </returns>

        public double SetTermTaxPercent()
        {
            Tax = MasterFileLocations.Rules.term.tax;
            return Tax;
        }
    }
}
