﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCalc.Backend
{
    /// <summary>
    /// This class basically keep all the constants constraints used in InsuranceCalc.
    /// </summary>
    public static class InsuranceConstant
    {

       /// <summary>
       /// These are constants.
       /// </summary>
        public const int MinValidAge = 20;
        public const int MaxValidAge = 60;
        public const int MinTenure = 10;
        public const int MaxTenure = 20;
    }
}
