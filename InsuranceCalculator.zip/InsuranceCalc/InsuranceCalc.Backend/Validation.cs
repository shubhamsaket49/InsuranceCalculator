﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCalc.Backend
{
    public class Validation
    {
        public static void ValidateAge(int age)
        {
            if(age<InsuranceConstant.MinValidAge || age>InsuranceConstant.MaxValidAge)
            {
                throw new Exception(MasterFileLocations.InvalidMsg.invalidAge.question);
            }
        }
        public static void ValidateTermAmount(int termSum)
        {
            int minimumAmount = MasterFileLocations.Rules.term.sumAssured.minAmount;
            int maximumAmount = MasterFileLocations.Rules.term.sumAssured.maxAmount;
            if (termSum< minimumAmount || termSum > maximumAmount)
            {
                throw new Exception(MasterFileLocations.InvalidMsg.invalidTerm.question);
            }
        }

        public static void ValidateEndowmentAmount(int endowmentSum)
        {
            int minimumAmount = MasterFileLocations.Rules.endowment.sumAssured.minAmount;
            int maximumAmount = MasterFileLocations.Rules.endowment.sumAssured.maxAmount;
            if (endowmentSum < minimumAmount || endowmentSum > maximumAmount)
            {
                throw new Exception(MasterFileLocations.InvalidMsg.invalidEndowment.question);
            }
        }
        public static void ValidateTenure(int duration)
        {
            if (duration < InsuranceConstant.MinTenure || duration> InsuranceConstant.MaxTenure)
            {
                throw new Exception(MasterFileLocations.InvalidMsg.invalidTenure.question);
            }
        }
    }
}
