﻿using System;

namespace InsuranceCalc.Backend
{
    public class TermPremiumCalculation
    {
        private int _sum;
        private double _normalPercent;
        private double _tax;
        private double _valueWithoutTax;
        private double _totalValueIncludingTax;

        TermCheck termCheck;
        public TermPremiumCalculation(TermCheck termCheck)
        {
            this.termCheck = termCheck;
        }
        public void PremiumAmountCalculation()
        {
            _sum = termCheck.GetTermSum();
            _normalPercent = termCheck.SetTotalTermPercent();
            _valueWithoutTax = (_sum * _normalPercent) / 100;
            _tax = termCheck.SetTermTaxPercent();
            _totalValueIncludingTax = _valueWithoutTax + (_valueWithoutTax * _tax) / 100;
            _totalValueIncludingTax= Math.Round(_totalValueIncludingTax, 2);
        }

        public double GetTermPremiumAmount()
        {
            return _totalValueIncludingTax;
        }
    }
}
