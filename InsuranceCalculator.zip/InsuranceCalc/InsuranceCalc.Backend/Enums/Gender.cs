﻿namespace InsuranceCalc.Backend
{
    public enum Gender
        {
            Male,
            Female,
            Others
        }
}
