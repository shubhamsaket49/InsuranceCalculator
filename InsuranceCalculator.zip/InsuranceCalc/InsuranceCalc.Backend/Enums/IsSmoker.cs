﻿namespace InsuranceCalc.Backend
{
    public partial class CommonCheck
    {
        public enum IsSmoker
        {
            Smoker,
            NotSmoker
        }
    }
}
