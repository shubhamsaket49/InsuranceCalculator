﻿using System;

namespace InsuranceCalc.Backend
{
    public class EndowmentCheck:CommonCheck
    {
        private int _endowmentAssured;
        private int _tenureDuration;
        private double _totalEndowmentPercent;
        private double _endowmentSmokerPercent;
        private double _percent;
        private double _tax;

        /// <summary>
        /// This method should use to validate the endowment amount entered by user.
        /// </summary>
        /// <exception cref="Exception">
        /// It will throw an error when user entered endowment amount which is out of the range.
        /// </exception>

        /// <summary>
        /// This method is used to set the endowment amount.
        /// </summary>
        /// <param name="SumAssured">
        /// This parameter helps to set the value of endowment amount
        /// </param>
        public void EndowmentSumAssured(int SumAssured)
        {
            _endowmentAssured = SumAssured;
        }

        /// <summary>
        /// This method will return the endowment amount
        /// </summary>
       
        public int GetEndowmentSum()
        {
            return _endowmentAssured;
        }

        /// <summary>
        /// This method should set the value of payment tenure
        /// </summary>
        /// <param name="duration"></param>
        public void SetPaymentTenure(int duration)
        {
            _tenureDuration =duration ;
        }

        /// <summary>
        /// This method will return the payment tenure opt by user
        /// </summary>
   
        public int GetTenure()
        {
            return _tenureDuration;
        }

        /// <summary>
        /// This method should return the respective percent according to the age.
        /// </summary>
        /// <param name="age">This parameter helps to pass the age of the user in this method</param>
        /// <returns>
        /// Returns percent based on the age of the user.
        /// </returns>
        /// <exception cref="Exception">
        /// Thrown if the age entered by user is not in the given range.
        /// </exception>
        public double SetEndowmentPercent(int age)
        {
            for (int i = 0; i < MasterFileLocations.Rules.endowment.age.Count; i++)
            {
                int MinAge = MasterFileLocations.Rules.endowment.age[i].minRange;
                int MaxAge = MasterFileLocations.Rules.endowment.age[i].maxRange;
                _percent = MasterFileLocations.Rules.endowment.age[i].percent;
                if (age >= MinAge && age <= MaxAge)
                    return _percent;
            }
            throw new Exception(MasterFileLocations.InvalidMsg.invalidAge.question);
        }

        /// <summary>
        /// This method should return the respective percent according to the smoking status of the user.
        /// </summary>
        /// <param name="isSmoker">
        /// This parameter helps to pass the age of the user in this method
        /// </param>
        /// <returns>
        /// Returns percent based on smoking status
        /// </returns>
        public double SetEndowmentSmokerPercent(IsSmoker isSmoker)
        {
            double _endowmentSmokerPercent = MasterFileLocations.Rules.endowment.smokingStatus.smoker;
            double _nonEndowmentSmokerPercent = MasterFileLocations.Rules.endowment.smokingStatus.notSmoker;
            if (IsSmoker.Smoker == isSmoker)
            {
                return _endowmentSmokerPercent;
            }
            return _nonEndowmentSmokerPercent;
        }

        /// <summary>
        /// This method should return total percent according to the age and smoking status of user
        /// </summary>
        /// <returns>
        /// Returns total percent
        /// </returns>
        public double SetTotalEndowmentPercent()
        {
            IsSmoker isSmoker = GetSmoker();
            int age = GetAge();
            _endowmentSmokerPercent = SetEndowmentSmokerPercent(isSmoker);
            double Percent = SetEndowmentPercent(age);

            _totalEndowmentPercent = _endowmentSmokerPercent + Percent;
            return _totalEndowmentPercent;
        }

        /// <summary>
        /// This method returns the percent of tax added while opting Endowment insurance policy.
        /// </summary>
        /// <returns>
        /// Returns the tax percent
        /// </returns>
        public double SetEndowmentTaxPercent()
        {
            _tax = MasterFileLocations.Rules.endowment.tax;
            return _tax;
        }
    }
}
