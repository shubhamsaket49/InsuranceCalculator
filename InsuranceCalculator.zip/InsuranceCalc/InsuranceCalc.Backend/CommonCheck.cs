﻿using System;
namespace InsuranceCalc.Backend
{
    /// <summary>
    /// This class should check the common constraints of Insurance Policy.
    /// </summary>

   public partial class CommonCheck
    {
        private int _age;
        private IsSmoker _isSmoker;

        /// <summary>
        ///  This method should set age with the given value of age.
        /// </summary>
        /// <param name="Age">Age of the user</param>
        public void SetAge(int Age)
        {
            _age = Age;
        }

        /// <summary>
        /// This method should return the age.
        /// </summary>
        public int GetAge()
        {
            return _age;
        }

        /// <summary>
        /// This method should take choice of the user and set their smoking status.
        /// </summary>
        /// <param name="userChoice">take the user choice</param>
        /// <exception cref="Exception"> Thrown when user will select any invalid option.</exception>
        public void SetSmoker(IsSmoker isSmoker)
        {
            _isSmoker= isSmoker;
        }

        /// <summary>
        /// This method should return the smoking status of the user.
        /// </summary>
        /// <returns>
        /// Smoking status of user.
        /// </returns>
        public IsSmoker GetSmoker()
        {
            return _isSmoker;
        }
    }
}
