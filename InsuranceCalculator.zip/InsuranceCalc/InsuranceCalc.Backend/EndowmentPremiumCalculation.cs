﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCalc.Backend
{
    /// <summary>
    /// This class basically store methods which calculate total premium amount of Endowment
    /// insurance and return the premium amount.
    /// </summary>
    public class EndowmentPremiumCalculation
    {
        /// <summary>
        /// These are the private data members of  class TermPremiumCalculation.
        /// </summary>
        
        private int _sum;
        private double _normalPercent;
        private int _duration;
        private double _tax;
        private double _totalValuePerYearIncludingTax;
        private double _valueWithoutTax;
        private double _valueWithoutTaxPerYear;

        /// <summary>
        /// This creates an instance of Term class.
        /// </summary>
        
        EndowmentCheck endowmentCheck;

        /// <summary>
        /// This is a constructor which takes endowmentCheck as a paramemter
        /// </summary>
        /// <param name="endowmentCheck"></param>
        public EndowmentPremiumCalculation(EndowmentCheck endowmentCheck)
        {
            this.endowmentCheck = endowmentCheck;
        }

        /// <summary>
        /// This method should calculate premium amount of term insurance.
        /// </summary>
        public void EndowmentPremiumAmountCalculation()
        {
            _sum = endowmentCheck.GetEndowmentSum();
            _normalPercent = endowmentCheck.SetTotalEndowmentPercent();
            _duration = endowmentCheck.GetTenure();
            _valueWithoutTax = ((_sum * _normalPercent) / 100 );
            _valueWithoutTaxPerYear = _valueWithoutTax / _duration;
            _tax = endowmentCheck.SetEndowmentTaxPercent();
            _totalValuePerYearIncludingTax = _valueWithoutTaxPerYear + (_valueWithoutTaxPerYear * _tax) / 100;
            _totalValuePerYearIncludingTax = Math.Round(_totalValuePerYearIncludingTax, 2);
        }

        /// <summary>
        /// This method should return total premium amount of endowment insurance.
        /// </summary>
        /// <returns>
        /// Total premium amount of endowment insurance.
        /// </returns>
        public double GetEndowmentPremiumAmount()
        {
            return _totalValuePerYearIncludingTax;
        }
    }
}
