﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using static InsuranceCalc.Backend.CommonCheck;

namespace InsuranceCalc.Backend.Tests
{
    public class TermPremiumCalculationTesting
    {
        public TermPremiumCalculationTesting()
        {
            MasterFileLocations.LoadLocations();
        }

        [Fact]
        public void TermPremiumCalculationShouldWork()
        {
            TermCheck termCheck = new TermCheck();
            TermPremiumCalculation termPremiumCalculation=new TermPremiumCalculation(termCheck);
            termCheck.TermSumAssured(10000000);
            termCheck.SetAge(27);
            termCheck.SetTermPercent();
            termCheck.SetSmoker(IsSmoker.NotSmoker);
            termCheck.SetTermSmokerPercent();
            termCheck.SetTermTaxPercent();
            termCheck.SetTotalTermPercent();
            termPremiumCalculation.PremiumAmountCalculation();
            Assert.Equal(11000, termPremiumCalculation.GetTermPremiumAmount());
        }
    }
}
