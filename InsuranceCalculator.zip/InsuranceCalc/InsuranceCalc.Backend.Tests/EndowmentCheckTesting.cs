using System;
using Xunit;
using static InsuranceCalc.Backend.CommonCheck;

namespace InsuranceCalc.Backend.Tests
{
    public class EndowmentCheckTesting
    {
        EndowmentCheck endowmentCheck = new EndowmentCheck();

        public EndowmentCheckTesting()
        {
            MasterFileLocations.LoadLocations();
        }
     
        [Fact]
        public void GetEndowmentPercentShouldWork()
        {
            Assert.Equal(40.0d, endowmentCheck.SetEndowmentPercent(24));
        }

        [Fact]
        public void GetEndowmentSmokerPercentShouldWork()
        {
            Assert.Equal(5, endowmentCheck.SetEndowmentSmokerPercent(IsSmoker.Smoker));
        }

        [Fact]
        public void SetEndowmentTaxPercentShouldWork()
        {
            Assert.Equal(10, endowmentCheck.SetEndowmentTaxPercent());
        }

        [Fact]
        public void SetTotalEndowmentPercentShouldWork()
        {
            endowmentCheck.SetAge(27);
            endowmentCheck.SetSmoker(IsSmoker.Smoker);
            Assert.Equal(45, endowmentCheck.SetTotalEndowmentPercent());
        }
    }
}
