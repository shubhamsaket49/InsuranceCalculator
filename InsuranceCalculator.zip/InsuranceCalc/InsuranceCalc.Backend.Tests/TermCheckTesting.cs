﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using static InsuranceCalc.Backend.CommonCheck;

namespace InsuranceCalc.Backend.Tests
{
    public class TermCheckTesting
    {
        TermCheck termCheck=new TermCheck();
        public TermCheckTesting()
        {
            MasterFileLocations.LoadLocations();
        }

        [Fact]
        public void GetTermPercentShouldWork()
        {
            termCheck.SetAge(32);
            Assert.Equal(0.15, termCheck.SetTermPercent());
        }

        [Fact]
        public void GetTermSmokerPercentShouldWork()
        {
            termCheck.SetSmoker(IsSmoker.Smoker);
            Assert.Equal(0.05, termCheck.SetTermSmokerPercent());
        }

        [Fact]
        public void SetTermTaxPercentShouldWork()
        {
            Assert.Equal(10, termCheck.SetTermTaxPercent());
        }

        [Fact]
        public void SetTotalTermPercentShouldWork()
        {
            termCheck.SetAge(32);
            termCheck.SetSmoker(IsSmoker.Smoker);
            Assert.Equal(0.20d, termCheck.SetTotalTermPercent());
        }
    }
}
