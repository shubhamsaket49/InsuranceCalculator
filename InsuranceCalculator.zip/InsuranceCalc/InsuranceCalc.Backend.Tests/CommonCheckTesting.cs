﻿using Xunit;
using static InsuranceCalc.Backend.CommonCheck;

namespace InsuranceCalc.Backend.Tests
{
    public class CommonCheckTesting
    {
        CommonCheck commonCheck = new CommonCheck();
        public CommonCheckTesting()
        {
            MasterFileLocations.LoadLocations();
        }

        [Fact]
        public void GetAgeShouldWork()
        {
            commonCheck.SetAge(27);
            Assert.Equal(27, commonCheck.GetAge());
        }

        [Fact]
        public void GetSmokerShouldWork()
        {
            commonCheck.SetSmoker(IsSmoker.NotSmoker);
            Assert.Equal(IsSmoker.NotSmoker, commonCheck.GetSmoker());
        }
    }
}
