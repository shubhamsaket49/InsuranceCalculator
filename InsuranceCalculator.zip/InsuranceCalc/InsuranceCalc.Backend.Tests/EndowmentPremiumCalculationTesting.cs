﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using static InsuranceCalc.Backend.CommonCheck;

namespace InsuranceCalc.Backend.Tests
{
    public class EndowmentPremiumCalculationTesting
    {
        public EndowmentPremiumCalculationTesting()
        {
            MasterFileLocations.LoadLocations();
        }

        [Fact]
        public void TermPremiumCalculationShouldWork()
        {
            EndowmentCheck endowmentCheck = new EndowmentCheck();
            EndowmentPremiumCalculation endowmentPremiumCalculation = new EndowmentPremiumCalculation(endowmentCheck);
            endowmentCheck.EndowmentSumAssured(1000000);
            endowmentCheck.SetAge(27);
            endowmentCheck.SetEndowmentPercent(27);
            endowmentCheck.SetSmoker(IsSmoker.Smoker);
            endowmentCheck.SetEndowmentSmokerPercent(IsSmoker.Smoker);
            endowmentCheck.SetPaymentTenure(15);
            endowmentCheck.SetEndowmentTaxPercent();
            endowmentCheck.SetTotalEndowmentPercent();
            endowmentPremiumCalculation.EndowmentPremiumAmountCalculation();
            Assert.Equal(33000, endowmentPremiumCalculation.GetEndowmentPremiumAmount());
        }
    }
}
