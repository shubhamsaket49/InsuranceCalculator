﻿using InsuranceCalc.Backend;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCalc.UI
{
    public class InputReader : IInputReader
    {
        private static readonly log4net.ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public string TakeInput(string fileRead)
        {
            Console.Write(fileRead);
            return Console.ReadLine();
        }
        public void DisplayInvalid(string displayMsg )
        {
            Console.WriteLine(displayMsg);
        }
    }
}
