﻿using InsuranceCalc.Backend;
using System;


namespace InsuranceCalc.UI
{
    internal class StartUserInput
    {
        private static readonly log4net.ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public void WelcomeMsg()
        {
            InputReader inputReader = new InputReader();
            Console.WriteLine(MasterFileLocations.WelcomeMsg.greeting.question);
            
            Console.WriteLine();
            
            foreach (var opt in MasterFileLocations.WelcomeMsg.insuranceChoice.options)
            {
                Console.WriteLine(opt.Key + " " + opt.Value);
            }
            while(true)
            {
                try
                {
                    Console.Write(MasterFileLocations.ShowLabel.choice.question);
                    int UserChoice = int.Parse(Console.ReadLine());
                    switch (UserChoice)
                    {
                        case 1:
                            TermCalculationOption();
                            return;
                        case 2:
                            EndowmentCalculationOption();
                            return;
                        default:
                            throw new Exception();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(MasterFileLocations.InvalidMsg.invalidChoices.question);
                    _log.Error(ex);
                }
            }
            
        }
        
        private void TermCalculationOption()
        {
            _log.Debug("User picked term sum calculation option");
            TermCheck termCheck = new TermCheck();

            ReadInsuranceDetails readInsuranceDetails = new ReadInsuranceDetails();
            readInsuranceDetails.GetTermInsuranceDetails(termCheck);


            TermPremiumCalculation termPremiumCalculation = new TermPremiumCalculation(termCheck);
            termPremiumCalculation.PremiumAmountCalculation();
            _log.Debug("Calculated amount: " + termPremiumCalculation.GetTermPremiumAmount());

            DisplayInsuranceDetails displayInsuranceDetails = new DisplayInsuranceDetails();
            displayInsuranceDetails.DisplayTermPremiumAmountCalculation(termPremiumCalculation);
        }

        private void EndowmentCalculationOption()
        {
            _log.Debug("User picked endowment sum calculation option");
            EndowmentCheck endowmentCheck = new EndowmentCheck();

            ReadInsuranceDetails readInsuranceDetails = new ReadInsuranceDetails();
            readInsuranceDetails.GetEndowmentInsuranceDetails(endowmentCheck);


            EndowmentPremiumCalculation endowmentPremiumCalculation = new EndowmentPremiumCalculation(endowmentCheck);
            endowmentPremiumCalculation.EndowmentPremiumAmountCalculation();
            _log.Debug("Calculated amount: " + endowmentPremiumCalculation.GetEndowmentPremiumAmount());

            DisplayInsuranceDetails displayInsuranceDetails = new DisplayInsuranceDetails();
            displayInsuranceDetails.DisplayEndowmentPremiumAmountCalculation(endowmentPremiumCalculation);

        }

       
    }
}
