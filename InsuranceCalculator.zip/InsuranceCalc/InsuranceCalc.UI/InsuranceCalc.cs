﻿using InsuranceCalc.Backend;
using System.IO;

namespace InsuranceCalc.UI
{
    internal class InsuranceCalc
    {
        private static readonly log4net.ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        static void Main(string[] args)
        {
            _log.Debug("Application Started");

            try
            {
                MasterFileLocations.LoadLocations();
            }

            catch (FileNotFoundException err)
            {
                _log.Error(err.Message);
                return;
            }

            catch (DirectoryNotFoundException err)
            {
                _log.Error(err.Message);
                return;
            }
            StartUserInput startUserInput = new StartUserInput();
            startUserInput.WelcomeMsg();
        }
    }
}
