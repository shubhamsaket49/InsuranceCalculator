﻿using InsuranceCalc.Backend;
using System;

namespace InsuranceCalc.UI
{
    internal class DisplayInsuranceDetails
    {
        private static readonly log4net.ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public void DisplayTermPremiumAmountCalculation(TermPremiumCalculation termPremiumCalculation)
        {
            Console.WriteLine(MasterFileLocations.CheckQues.term.question+" "+ MasterFileLocations.CheckQues.finalPremium.question+" "+termPremiumCalculation.GetTermPremiumAmount()); 
        }
        public void DisplayEndowmentPremiumAmountCalculation(EndowmentPremiumCalculation endowmentPremiumCalculation)
        {
            Console.WriteLine(MasterFileLocations.CheckQues.endowment.question+" "+ MasterFileLocations.CheckQues.finalPremium.question+" "+endowmentPremiumCalculation.GetEndowmentPremiumAmount());
        }
    }
}
