﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceCalc.UI
{
    public interface IInputReader
    {
        public string TakeInput(string fileRead);
        public void DisplayInvalid(string displayMsg);
    }

   
}
