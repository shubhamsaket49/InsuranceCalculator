﻿using InsuranceCalc.Backend;
using System;
using static InsuranceCalc.Backend.CommonCheck;

namespace InsuranceCalc.UI
{
    internal class ReadInsuranceDetails
    {
        private static readonly log4net.ILog _log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public void GetTermInsuranceDetails(TermCheck termCheck)
        {
            
            InputReader inputReader = new InputReader();
            Console.WriteLine();
            int termSum = GetTermSumAssured(inputReader);
            termCheck.TermSumAssured(termSum);

            Console.WriteLine();
            int age = GetAgeInput(inputReader);
            termCheck.SetAge(age);

            Console.WriteLine();

            foreach (var opt in MasterFileLocations.CheckQues.smoker.options)
            {
                Console.WriteLine(opt.Key + " " + opt.Value);
            }

            IsSmoker FindSmoker = GetSmokerInput(inputReader);
            termCheck.SetSmoker(FindSmoker);

            _log.Debug(termCheck);
            Console.WriteLine();

        }


        public void GetEndowmentInsuranceDetails(EndowmentCheck endowmentCheck)
        {

            InputReader inputReader = new InputReader();
            Console.WriteLine();
            int endowmentSum = GetEndowmentSumAssured(inputReader);
            endowmentCheck.EndowmentSumAssured(endowmentSum);
            
            Console.WriteLine();

            int age = GetAgeInput(inputReader);
            endowmentCheck.SetAge(age);
            
            Console.WriteLine();

            foreach (var opt in MasterFileLocations.CheckQues.smoker.options)
            {
                Console.WriteLine(opt.Key + " " + opt.Value);
            }

            IsSmoker findSmoker = GetSmokerInput(inputReader);
            endowmentCheck.SetSmoker(findSmoker);
           
            Console.WriteLine();

            int tenure=GetTenureInput(inputReader);
            endowmentCheck.SetPaymentTenure(tenure);
            _log.Debug(endowmentCheck);
            Console.WriteLine();
        }

        
        private static int GetTermSumAssured(InputReader inputReader)
        {
            Console.WriteLine(MasterFileLocations.CheckQues.termSum.question);
            while (true)
            {
                try
                {
                    int sumAssured = int.Parse(inputReader.TakeInput(MasterFileLocations.ShowLabel.sumValue.question));
                    Validation.ValidateTermAmount(sumAssured);
                    _log.Debug("Term sum validated: " + sumAssured);
                    return sumAssured;
                }
                catch (OverflowException ex)
                {
                    Console.WriteLine(ex.Message);
                    _log.Debug("Failed to validate: "+ ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    _log.Debug("Failed to validate: " + ex.Message);
                }
            }
        }

        private int GetAgeInput(InputReader inputReader)
        {
            Console.WriteLine(MasterFileLocations.CheckQues.age.question);
           
            while (true)
            {
                int age = int.Parse(inputReader.TakeInput(MasterFileLocations.ShowLabel.age.question));
                try
                {
                    Validation.ValidateAge(age);
                    _log.Debug("Age validated: " + age);
                    return age;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    _log.Debug("Failed to validate: " + ex.Message);
                }
            }
        }
        private static IsSmoker GetSmokerInput(InputReader inputReader)
        {
            Console.WriteLine(MasterFileLocations.CheckQues.smoker.question);
            while (true)
            {
                
                try
                {
                    int userChoice = Convert.ToInt32(inputReader.TakeInput(MasterFileLocations.ShowLabel.smokingChoice.question));
                    switch (userChoice)
                    {
                        case 1:
                            return IsSmoker.Smoker;

                        case 2:
                            return IsSmoker.NotSmoker;

                        default:
                            throw new Exception();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(MasterFileLocations.InvalidMsg.invalidSmokingStatus.question);
                    _log.Debug("Failed to validate: " + ex.Message);
                }

            }
        }

       


        private static int GetEndowmentSumAssured(InputReader inputReader)
        {
           
            Console.WriteLine(MasterFileLocations.CheckQues.endowmentSum.question);
            while (true)
            {

                try
                {
                    int sumAssured = int.Parse(inputReader.TakeInput(MasterFileLocations.ShowLabel.sumValue.question));
                    Validation.ValidateEndowmentAmount(sumAssured);
                    _log.Debug("Endowment sum validated: " + sumAssured);
                    return sumAssured;

                }
                catch (OverflowException ex)
                {
                    Console.WriteLine(ex.Message);
                    _log.Debug("Failed to validate: " + ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    _log.Debug("Failed to validate: " + ex.Message);
                }
            }
        }

        private int GetTenureInput(InputReader inputReader)
        {
            Console.WriteLine(MasterFileLocations.CheckQues.tenure.question);

            while (true)
            {
                try
                {
                    int duration = int.Parse(inputReader.TakeInput(MasterFileLocations.ShowLabel.duration.question));
                    Validation.ValidateTenure(duration);
                    _log.Debug("Insurance Duration validated: " + duration);
                    return duration;
                }

                catch (OverflowException ex)
                {
                    Console.WriteLine(ex.Message);
                    _log.Debug("Failed to validate: " + ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    _log.Debug("Failed to validate: " + ex.Message);
                }
            }
        }

    }
}
