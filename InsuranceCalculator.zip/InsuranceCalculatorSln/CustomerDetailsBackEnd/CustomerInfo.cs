﻿using PolicyBasic;
using System;
using System.IO;

namespace KYCDetails
{
    public class CustomerInfo
    {
        private string _firstName;
        private string _lastName;
        private Gender _gender;
        private DateTime _dob;
        private int _adhaar;
        public void CustomerFName()
        {
            string CustFirstName = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\CustName.txt";
            string FirstName = File.ReadAllText(CustFirstName);
            Console.WriteLine(FirstName);
            _firstName = Console.ReadLine();

        }

        public string DisplayFirstName()
        {
            return _firstName;
        }

        public void CustomerLName()
        {
            string CustLastName = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\CustLastName.txt";
            string LastName = File.ReadAllText(CustLastName);
            Console.WriteLine(LastName);
            _lastName = Console.ReadLine();

        }

        public string DisplayLastName()
        {
            return _lastName;
        }

        public void CustomerGender()
        {
            string CustGender = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\CustGender.txt";
            _gender = Gender.Others;
            string GetGender = File.ReadAllText(CustGender);
            Console.WriteLine(GetGender);
            int userChoice = Convert.ToInt32(Console.ReadLine());
            switch (userChoice)
            {
                case 1:
                    _gender = Gender.Male;
                    break;
                case 2:
                    _gender = Gender.Female;
                    break;
                case 3:
                    _gender = Gender.Others;
                    break;
            }
        }

        public Gender DisplaySmoker()
        {
            return _gender;
        }

        public void CustomerDob()
        {
            string CustDateOfBirth = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\CustDob.txt";
            string DateOfBirth = File.ReadAllText(CustDateOfBirth);
            Console.WriteLine(DateOfBirth);
            _dob = DateTime.Parse(Console.ReadLine());

        }

        public DateTime DisplayDateOfBirth()
        {
            return _dob;
        }

        public void CustomerAdhaar()
        {
            string CustAdhaar = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\CustAdhaar.txt";
            int AdhaarNumber = int.Parse(File.ReadAllText(CustAdhaar));
            Console.WriteLine(AdhaarNumber);
            _adhaar = int.Parse(Console.ReadLine());

        }

        public int DisplayAdhaar()
        {
            return _adhaar;
        }
    }
}
