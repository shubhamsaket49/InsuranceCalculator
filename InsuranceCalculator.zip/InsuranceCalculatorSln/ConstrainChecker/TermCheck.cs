﻿using CommonConstraintChecker;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace TermInsuranceConstraintChecker
{
    public class TermCheck:CommonCheck
    {
        private int _sumAssured;
        private double _totalPercent;
        string[] CheckTermPercent;
        double ApplicablePercent;
        private int _CustomerAge;
        public void ValidateTermAmount()
        {
            string ValidateTerm = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\ValidateTerm.txt";
            StreamReader sr = new StreamReader(ValidateTerm);
            sr.ReadLine();

            string[] ValidatingTermAmount = sr.ReadLine().Split(',');
            int minimumAmount = int.Parse(ValidatingTermAmount[0]);
            int maximumAmount = int.Parse(ValidatingTermAmount[1]);
            sr.Close();
            if (_sumAssured < minimumAmount || _sumAssured > maximumAmount)
            {
                string InvalidTerm = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\InvalidTerm.txt";
                string msgInvalidTerm = File.ReadAllText(InvalidTerm);
                Console.WriteLine(msgInvalidTerm);
                TermSumAssured();
            }
        }

        public void TermSumAssured()
        {
            string TermSum = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\TermSum.txt";
            string msgTermSum = File.ReadAllText(TermSum);
            Console.WriteLine(msgTermSum);
            _sumAssured = Convert.ToInt32(Console.ReadLine());

            ValidateTermAmount();
        }

        public int DisplaySumAssured()
        {
            return _sumAssured;
        }

        public double GetPercent(int Age)
        {
            string TermPercent = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\ConstraintCheckers\CheckerFiles\TermPercent.txt";
            using (StreamReader sr = new StreamReader(TermPercent))
            {
                sr.ReadLine();

                string csvLine;
                while ((csvLine = sr.ReadLine()) != null)
                {
                    string[] line = csvLine.Split(',');
                    int MinAge=int.Parse(line[0]);
                    int MaxAge=int.Parse(line[1]);
                    double Percent=double.Parse(line[2]);
                    if(Age >= MinAge && Age<=MaxAge)
                        return Percent;
                    
                }
                throw new Exception("Invalid Age");
            }
        }

        
       

        }
 }

