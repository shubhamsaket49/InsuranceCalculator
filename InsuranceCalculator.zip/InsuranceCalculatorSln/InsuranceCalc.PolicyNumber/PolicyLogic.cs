﻿using PolicyBasic;
using System;
using LQS.Util.IDGenNext;
using PolicyNumberGeneration;

namespace PolicyNumberLogic
{
    public class PolicyLogic:PolicyBase
    {
        private int _adhaar;
        public PolicyLogic(string firstName, string lastName,  Gender gender, DateTime dOB)
        {
            FirstName = firstName;
            LastName = lastName;
            Gender = gender;
            DOB = dOB;
            _adhaar= GetAdhaar(); 
        }
    }
}
