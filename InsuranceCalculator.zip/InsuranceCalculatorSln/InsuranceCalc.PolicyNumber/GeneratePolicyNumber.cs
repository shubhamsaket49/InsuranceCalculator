﻿using PolicyBasic;
using System;

namespace PolicyNumberGeneration
{
   
    internal interface IPolicyNumberGenerator
    {
        public string NextId();
    }
    public class GeneratePolicyNumber:PolicyBase
    {
        private string _policyNumber;
        private void GeneratePolicy()
        {
            _policyNumber = FirstName + GetAdhaar() + DOB.Year;
        }
        public string DisplayPolicyNumber()
        {
            return _policyNumber; 
        }
    }
}
