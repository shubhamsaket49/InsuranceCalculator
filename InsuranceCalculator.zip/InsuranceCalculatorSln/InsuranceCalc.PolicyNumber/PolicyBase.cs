﻿using System;

namespace PolicyBasic
{
    public class PolicyBase
    {
        private string _policyNumber { get; set; }
        protected string FirstName { get; set; }
        protected string LastName { get; set; }

        private Gender _gender;
        protected Gender Gender
        {
            get { return _gender; }
            set { _gender = value; }
        }
       
        protected DateTime DOB { get; set; }
        
        private int _adhaar;

        protected int GetAdhaar()
        {
           return _adhaar;
        }
    }
    public enum Gender
    {
        Male,
        Female,
        Others

    }
}

