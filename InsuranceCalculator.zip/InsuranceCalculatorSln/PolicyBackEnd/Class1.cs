﻿using System;

namespace PolicyBackEnd
{
    public class Class1
    {
    }
}
