﻿using PolicyBasic;
using System;
using LQS.Util.IDGenNext;
namespace PolicyNumberLogic
{
    public class PolicyLogic:PolicyBase
    {
        public PolicyLogic(string fname, string sname,  Gender gender, DateTime dOB, int adhaar)
        {
            FirstName = fname;
            SecondName = sname;
            Gender = gender;
            DOB = dOB;
            Adhaar = adhaar;
            PolicyNumber = new IDGen().NextId();
        }
        public string Display()
        {
            return PolicyNumber;
        }
    }
}
