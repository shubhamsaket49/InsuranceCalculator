﻿using System;

namespace PolicyBasic
{
    public class PolicyBase
    {
        protected string PolicyNumber { get; set; }
        public string FirstName { get; set; }
        public string SecondName { get; set; }

        private Gender _gender;
        public Gender Gender
        {
            get { return _gender; }
            set { _gender = value; }
        }
       
        public DateTime DOB { get; set; }
        public int Adhaar { get; set; }
    }

    public enum Gender
    {
        Male,
        Female,
        Others

    }
}

