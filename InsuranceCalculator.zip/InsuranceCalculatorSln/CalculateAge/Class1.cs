﻿using System;

namespace CalculateAge
{
    public class Class1
    {
    }
}
