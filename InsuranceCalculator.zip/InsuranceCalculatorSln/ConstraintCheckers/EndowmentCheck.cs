﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
namespace EndowmentInsuranceConstraintChecker
{
    public class EndowmentCheck
    {
        private int _endowmentAssured;
        private int _tenureDuration;
        public void ValidateEndowmentAmount()
        {
            string ValidateEndowment = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\ValidateEndowment.txt";
            StreamReader sr = new StreamReader(ValidateEndowment);
            sr.ReadLine();

            string[] ValidatingEndowmentAmount = sr.ReadLine().Split(',');
            int miniAmount = int.Parse(ValidatingEndowmentAmount[0]);
            int maxiAmount = int.Parse(ValidatingEndowmentAmount[1]);
            sr.Close();
            if (_endowmentAssured < miniAmount || _endowmentAssured > maxiAmount)
            {
                string InvalidEndowment = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\InvalidEndowment.txt";
                string msgInvalidEndowment = File.ReadAllText(InvalidEndowment);
                Console.WriteLine(msgInvalidEndowment);
                EndowmentSumAssured();
            }
        }

        public void EndowmentSumAssured()
        {
            string EndowmentSum = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\EndowmentSum.txt";
            string msgEndowmentSum = File.ReadAllText(EndowmentSum);
            Console.WriteLine(msgEndowmentSum);
            _endowmentAssured = Convert.ToInt32(Console.ReadLine());

            ValidateEndowmentAmount();
        }
        public int DisplayEndowmentSum()
        {
            return _endowmentAssured;
        }
        public void PaymentTenure()
        {
            string Tenure = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\Tenure.txt";
            string msgTenure = File.ReadAllText(Tenure);
            Console.WriteLine(msgTenure);
            _tenureDuration = Convert.ToInt32(Console.ReadLine());  
        }

        public int DisplayTenure()
        {
            return _tenureDuration;
        }
    }
}
