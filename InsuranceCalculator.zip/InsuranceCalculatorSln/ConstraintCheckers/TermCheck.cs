﻿using CommonConstraintChecker;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace TermInsuranceConstraintChecker
{
    public class TermCheck:CommonCheck
    {
        private int _sumAssured;
        private double _totalPercent;
        string[] CheckTermPercent;
        double ApplicablePercent;
        private int _CustomerAge;
        public void ValidateTermAmount()
        {
            string ValidateTerm = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\ValidateTerm.txt";
            StreamReader sr = new StreamReader(ValidateTerm);
            sr.ReadLine();

            string[] ValidatingTermAmount = sr.ReadLine().Split(',');
            int minimumAmount = int.Parse(ValidatingTermAmount[0]);
            int maximumAmount = int.Parse(ValidatingTermAmount[1]);
            sr.Close();
            if (_sumAssured < minimumAmount || _sumAssured > maximumAmount)
            {
                string InvalidTerm = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\InvalidTerm.txt";
                string msgInvalidTerm = File.ReadAllText(InvalidTerm);
                Console.WriteLine(msgInvalidTerm);
                TermSumAssured();
            }
        }

        public void TermSumAssured()
        {
            string TermSum = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\TermSum.txt";
            string msgTermSum = File.ReadAllText(TermSum);
            Console.WriteLine(msgTermSum);
            _sumAssured = Convert.ToInt32(Console.ReadLine());

            ValidateTermAmount();
        }

        public int DisplaySumAssured()
        {
            return _sumAssured;
        }



        Dictionary<int, double> ValidatingTermPercent = new Dictionary<int, double>();
        public Dictionary<int,double> ValidateTermPercent()
        {
            #region
            //int Age = DisplayAge();
            //string TermPercent = @"C:\LeadSquared\Platform Training\Coding\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\TermPercent.txt";
            //StreamReader sr = new StreamReader(TermPercent);
            //sr.ReadLine();

            //CheckTermPercent = sr.ReadLine().Split(',');
            //CustomerAge = int.Parse(CheckTermPercent[Age]);
            //ApplicablePercent = double.Parse(CheckTermPercent[Age]);
            //Console.WriteLine(ApplicablePercent);

            //if (_sumAssured < minimumAmount || _sumAssured > maximumAmount)
            //{
            //    string InvalidTerm = @"C:\LeadSquared\Platform Training\Coding\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\Invalid.txt";
            //    string msgInvalidTerm = File.ReadAllText(InvalidTerm);
            //    Console.WriteLine(msgInvalidTerm);
            //    TermSumAssured();
            //}
            #endregion

            string TermPercent = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\TermPercent.txt";
            using (StreamReader sr = new StreamReader(TermPercent))
            {
                sr.ReadLine();
                string csvLine;
                while((csvLine=sr.ReadLine()) !=null)
                {
                    string[] line = csvLine.Split(',');
                    _CustomerAge = int.Parse(line[0]);
                    double ApplicablePercent = double.Parse(line[1]);
                    ValidatingTermPercent.Add(_CustomerAge,ApplicablePercent);
                }

            }
            return ValidatingTermPercent;

        }
        public void IsPercent()
        {
            ValidateTermPercent();
            int Age = DisplayAge();
            Console.WriteLine(Age);
            //Console.WriteLine(ValidatingTermPercent[Age]);
            
            //if (CustomerAge >= 20 && CustomerAge < 30)
            //{

            //    if (_isSmoker == IsSmoker.Smoker)
            //    {

            //    }
            //    ApplicablePercent = int.Parse(CheckTermPercent[CustomerAge]);
            //}
            //else if (CustomerAge >= 30 && CustomerAge < 40)
            //{
            //    if (_isSmoker == IsSmoker.Smoker)
            //    {
            //        _totalPercent = 0.2;
            //    }
            //    ApplicablePercent = int.Parse(CheckTermPercent[1]);
            //}

            //else if (CustomerAge >= 40 && CustomerAge < 50)
            //{

            //    if (_isSmoker == IsSmoker.Smoker)
            //    {
            //        _totalPercent = 0.25;
            //    }
            //    ApplicablePercent = int.Parse(CheckTermPercent[CustomerAge]);
            //}
            //else if (CustomerAge >= 50 && CustomerAge < 60)
            //{

            //    if (_isSmoker == IsSmoker.Smoker)
            //    {
            //        _totalPercent = 0.3;
            //    }
            //    ApplicablePercent = int.Parse(CheckTermPercent[CustomerAge]);
            //}



        }
    }
}
