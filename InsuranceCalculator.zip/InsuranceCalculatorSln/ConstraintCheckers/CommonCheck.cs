﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CommonConstraintChecker
{
    public class CommonCheck
    {
        private int _ageCalculate;
        private IsSmoker _isSmoker;


        public void AgeCalculate()
        {
            string CheckAge = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\CheckAge.txt";
            string CustAge = File.ReadAllText(CheckAge);
            Console.WriteLine(CustAge);
            _ageCalculate = Convert.ToInt32(Console.ReadLine());
        }
        public int DisplayAge()
        {
            return _ageCalculate;
        }

        public enum IsSmoker
        {
            Smoker,
            NotSmoker
        }

        public void Smoker()
        {
            string CheckSmoker = @"C:\LeadSquared\Platform Training\Module- 1 C# Training\Project- Module1\InsuranceCalculatorSln\InsuranceCalculator\bin\Debug\net5.0\Files\CheckSmoker.txt";

            _isSmoker = IsSmoker.NotSmoker;
            string CustIsSmoke = File.ReadAllText(CheckSmoker);
            Console.WriteLine(CustIsSmoke);
            int userChoice = Convert.ToInt32(Console.ReadLine());
            switch (userChoice)
            {
                case 1:
                    _isSmoker = IsSmoker.Smoker;
                    break;
                case 2:
                    _isSmoker = IsSmoker.NotSmoker;
                    break;
            }
        }
        public IsSmoker DisplaySmoker()
        {
            return _isSmoker;
        }
    }
}
