﻿using CommonConstraintChecker;
using EndowmentInsuranceConstraintChecker;
using System;
using TermInsuranceConstraintChecker;

namespace InsuranceCalculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CommonCheck commonCheck = new CommonCheck();
            commonCheck.AgeCalculate();
            commonCheck.Smoker();
            TermCheck termCheck = new TermCheck();
            termCheck.TermSumAssured();
            EndowmentCheck endowmentCheck = new EndowmentCheck();
            endowmentCheck.EndowmentSumAssured();
            Console.WriteLine(endowmentCheck.DisplayEndowmentSum());
            termCheck.IsPercent();
        }
    }
}
