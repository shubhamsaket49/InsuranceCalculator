﻿using PolicyBasic;
using System;

namespace PolicyNumberGeneration
{
    public class GeneratePolicyNumber:PolicyBase
    {
        public string NextId()
        {
            DateTime dt = DateTime.Now;
            var rdm = FirstName + Adhaar + DOB.Year;
            return rdm;
        }

    }
}
